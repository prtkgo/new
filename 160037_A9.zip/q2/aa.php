<?php

if(!isset($_COOKIE["username"]) || !isset($_COOKIE["pass"])){
    if(isset($_POST['username']) && isset($_POST['pass'])){
        $tempUsrName = $_POST['username'] ;
        $tempPass = $_POST['pass'] ;

        if(($tempUsrName=="abhi" && $tempPass=="abhi") ){
           // $_COOKIE["username"] = $_POST['username'];
            setcookie("username",$_POST['username'] , time() + (860 ), "/");
            setcookie("pass", $_POST['pass'], time() + (860 ), "/");
            //$_COOKIE["pass"] = $_POST['pass'];
            //echo $_COOKIE["pass"];
        }

    }
}
     if(isset($_COOKIE["username"]) && isset($_COOKIE["pass"])){
        $username = $_COOKIE["username"];
        //echo $_COOKIE["username"];
    }
    if(!isset($_COOKIE["username"]) || ! isset($_COOKIE["pass"])) {
        //echo "<script> location.replace('login.html'); </script>";
        header('Location: admin_login.html');
        exit();
    }


?>
<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
</head>
<body>
<div class='container' >
<div style='padding: 30px;'>
<table class='table-striped table-bordered table table-hover'>
<h2>Bank User Data</h2>
 <thead>
   <tr>
     <th>Email</th>
     <th>Name</th>
     <th>Phone</th>
     <th>Account No</th>
     <th>Address</th>
   </tr>
 </thead>
 <tbody>
<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('reg.db');
      }
   }

   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      echo "\n";
   }

   $sql =<<<EOF
      SELECT * from BANK;
EOF;

   $ret = $db->query($sql);

   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {

       echo "<tr>
        <td>". $row['EMAIL'] ."</td>
        <td>" .$row['NAME'] ." </td>
        <td> ". $row['PHONE'] ."</td>
        <td> ". $row['BANKACCOUNT']." </td>
        <td> ". $row['ADDRESS'] ." </td>
      </tr>";


   }
   echo "  </tbody>
  </table>
</div>
</div>
";
   $db->close();
?>
<center> <a href="index.html"> Another Registration </a> </center>
</body>
</html>
