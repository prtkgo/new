## index.html
A file containing the registration page.
## admin_login.html
File containing the authentication portal for admin_login
## creater_table.php
File to create table for Registrations
## register.php
File for registrations without accounts
## register_new.php
File for registrations with accounts
## add_bank_acc.php
File to add bank accounts to db
## fetch_accounts.php
File to fetch data of bank ACCOUNTS
## aa.php
File containing registered data
