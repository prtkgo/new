<?php

	$name = $_POST["name"];
	$address = $_POST["address"];
	$email = $_POST["email"];
	$bank = $_POST["bank"];
	$mobile = $_POST["mobile"];
	$bankpass = $_POST["bankpass"];
		
	class MyDB extends SQLite3 {
      function __construct() {
         $this->open('test.db');
      }
   }
   
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } else {
      echo "Opened database successfully\n";
   }

   $sql =<<<EOF
      INSERT INTO INFO (NAME,ADDRESS,EMAIL,MOBILENUMBER,BANKNUMBER,PASSWORD)
      VALUES ('$name', '$address', '$email', '$mobile', '$bank', '$bankpass' );

EOF;

   $ret = $db->exec($sql);
   if(!$ret) {
      echo $db->lastErrorMsg();
   } else {
      echo "Records created successfully\n";
   }
   $db->close();
?>
