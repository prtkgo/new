function form_validation() {
    var flag = 0;
    var name = document.forms["reg_form"]["name"].value;
    var addr = document.forms["reg_form"]["address"].value;
    var mail = document.forms["reg_form"]["email"].value;
    var phone = document.forms["reg_form"]["phone"].value;
    var bank_acc = document.forms["reg_form"]["bank_acc"].value;
    var password = document.forms["reg_form"]["password"].value;
    var tmpname = name ;
    var regex = /^[a-zA-Z]+$/ ;
    if (name.length > 20) {
        document.getElementById("error_nameLen").style.display = "block" ;
        flag = 1 ;
    }
    var tmpname = name.replace(/ /g,'') ;
    if(!tmpname.match(regex)){
        document.getElementById("error_nameLen").innerHTML = "Name must be in english" ;
        document.getElementById("error_nameLen").style.display = "block" ;
        flag = 1 ;
    }
    if (name.length == 0) {
        document.getElementById("error_nameLen").innerHTML = "Name must be non-empty" ;
        document.getElementById("error_nameLen").style.display = "block" ;
        flag = 1 ;
    }
    if (addr.length > 100) {
        document.getElementById("error_addr").style.display = "block" ;
        flag = 1 ;
    }
    if (addr.length == 0) {
        document.getElementById("error_addr").innerHTML = "Address must be non-empty" ;
        document.getElementById("error_addr").style.display = "block" ;
        flag = 1 ;
    }
    if (phone.length == 0) {
        document.getElementById("error_phone").innerHTML = "Phone No must be non-empty" ;
        document.getElementById("error_phone").style.display = "block" ;
        flag = 1 ;
    }
    if (isNaN(phone) || phone < Math.pow(10, 9) || phone >= Math.pow(10, 10)) {
        document.getElementById("error_phone").style.display = "block" ;
        flag = 1 ;
    }
    if (bank_acc.length == 0) {
        document.getElementById("error_bank").innerHTML = "Bank Account No must be non-empty" ;
        document.getElementById("error_bank").style.display = "block" ;
        flag = 1 ;
    }
    if (isNaN(bank_acc) || bank_acc < Math.pow(10, 4) || bank_acc >= Math.pow(10, 5)) {
        document.getElementById("error_bank").style.display = "block" ;
        flag = 1 ;
    }
    if (password.length > 20) {
        document.getElementById("error_pass").style.display = "block" ;
        flag = 1 ;
    }
    if (password.length == 0) {
        document.getElementById("error_pass").innerHTML = "Password must be non-empty" ;
        document.getElementById("error_pass").style.display = "block" ;
        flag = 1 ;
    }
    if (mail.length == 0) {
        document.getElementById("error_email").innerHTML = "Email must be non-empty" ;
        document.getElementById("error_email").style.display = "block" ;
        flag = 1 ;
    }
    var tmp = mail.split("@")[1];
    if (tmp.split(".")[1] != "com") {
        document.getElementById("error_email").style.display = "block" ;
        flag = 1 ;
    }
    if(flag == 0){
        document.getElementById("register_form").submit();
    }
}
