<!DOCTYPE html>
<html lang="en">
    <head>
		<meta name="viewport" content="width=device-width, initial-scale=1">


		<!-- Website CSS style -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<!-- Website Font style -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

		<title>Let's Build Stuff</title>
	</head>
	<body>
		<div class="container" style="margin-top : 200px;">
			<div class="row main">
				<div class="main-login main-center">
				<center><h3>Registration Status</h3> </center>

<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('reg.db');
      }
   }
   class MyDB1 extends SQLite3 {
      function __construct() {
         $this->open('accounts.db');
      }
   }
   $db1 = new MyDB1();
   if(!$db1) {
      echo $db1->lastErrorMsg();
   } else {
      echo "\n";
   }

   $name = $_POST["name"] ;
   $phone = $_POST["phone"] ;
   $email = $_POST["email"] ;
   $address = $_POST["address"] ;
   $bank = $_POST["bank_acc"] ;
   $password = $_POST["password"] ;
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } else {
      echo "\n";
   }
   $sql1 =<<<EOF
      SELECT * from ACCOUNTS WHERE BANKACCOUNT = '$bank';

EOF;
    $some_flag = 0;
    $ret1 = $db1->query($sql1);
    while($row1 = $ret1->fetchArray(SQLITE3_ASSOC) ) {
        $balance = $row1['BALANCE'] ;
        $pass_acc =  $row1['PASSWORD'] ;
       // echo "ID = ". $row1['BANKACCOUNT'] . "\n";
       // echo "NAME = ". $row1['BALANCE'] ."\n";
       // echo "ADDRESS = ". $row1['PASSWORD'] ."\n";
    }
   $sql =<<<EOF
   INSERT INTO BANK (EMAIL,NAME,BANKACCOUNT,PHONE,PASSWORD,ADDRESS)
   VALUES ('$email', '$name', '$bank', '$phone', '$password', '$address' );

EOF;

try{
//error handler function
function customError($errno, $errstr) {
  if($errno == 2){
      // echo "$errno $errstr \n";
      echo "<center><h4>Already Registered</h4> </center>" ;

      throw new Exception("Already Registered");

  }
}

//set error handler
set_error_handler("customError");
$ret = $db->exec($sql);

//trigger error

}
catch (Exception $e) {
   echo "<center><h4>Already Registered</h4> </center>" ;
}
   if(!$ret) {
      // echo $db->lastErrorMsg();
   } else {
       if($pass_acc != $password){
           $sql =<<<EOF
                 DELETE from BANK where BANKACCOUNT = $bank;
EOF;
              echo "Password and account didn't match.";
              $ret = $db->exec($sql);
              if(!$ret){
                echo $db->lastErrorMsg();
              }
       }
       else if($balance < 1000){
           $sql =<<<EOF
                 DELETE from BANK where BANKACCOUNT = $bank;
EOF;
              echo "Insufficient balance";
              $ret = $db->exec($sql);
              if(!$ret){
                echo $db->lastErrorMsg();
              }
       }

      else {
          $balance = $balance - 1000 ;
          $sql1 =<<<EOF
                UPDATE ACCOUNTS set BALANCE = '$balance'  where BANKACCOUNT=$bank;
EOF;
   $ret1 = $db1->exec($sql1);

          echo "<center><h4>Registration Successful</h4> </center>";
          echo "<center> <h5> Balance Left : " . $balance ."</h5></center>";
      }
   }
   $db->close();
?>
<a href="index.html"type="button" class="btn btn-primary btn-lg btn-block "> Another Registration </a>
</div>
</div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script src="script.js"> </script>
</body>
</html>
