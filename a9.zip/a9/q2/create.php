<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('test.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      echo "Opened database successfully\n";
   }

   $sql =<<<EOF
      CREATE TABLE INFO
      (NAME  TEXT,
       ADDRESS  CHAR(100),
       EMAIL VARCHAR(50) PRIMARY KEY,
       MOBILENUMBER  INT,
       BANKNUMBER  INT,
       PASSWORD  VARCHAR(50));
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>
