<!DOCTYPE html>
<html lang="en">
    <head>
		<meta name="viewport" content="width=device-width, initial-scale=1">


		<!-- Website CSS style -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<!-- Website Font style -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

		<title>Let's Build Stuff</title>
	</head>
	<body>
		<div class="container" style="margin-top : 200px;">
			<div class="row main">
				<div class="main-login main-center">
				<center><h3>Registration Status</h3> </center>

<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('reg.db');
      }
   }
   
   $name = $_POST["name"] ;
   $phone = $_POST["phone"] ;
   $email = $_POST["email"] ;
   $address = $_POST["address"] ;
   $bank = $_POST["bank_acc"] ;
   $password = $_POST["password"] ;
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } else {
      echo "\n";
   }
   $sql =<<<EOF
   INSERT INTO BANK (EMAIL,NAME,BANKACCOUNT,PHONE,PASSWORD,ADDRESS)
   VALUES ('$email', '$name', '$bank', '$phone', '$password', '$address' );



EOF;

try{
//error handler function
function customError($errno, $errstr) {
  if($errno == 2){
      // echo "$errno $errstr \n";
      throw new Exception("Already Registered");

  }
}

//set error handler
set_error_handler("customError");
$ret = $db->exec($sql);

//trigger error

}
catch (Exception $e) {
   echo "<center><h4>Already Registered</h4> </center>" ;
}
   if(!$ret) {
      // echo $db->lastErrorMsg();
   } else {
      echo "<center><h4>Registration Successful</h4> </center>";
   }
   $db->close();
?>
<a href="index.html"type="button" class="btn btn-primary btn-lg btn-block "> Another Registration </a>
</div>
</div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script src="script.js"> </script>
</body>
</html>
