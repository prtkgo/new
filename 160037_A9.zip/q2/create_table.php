<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('reg.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      echo "Opened database successfully\n";
   }

   $sql =<<<EOF
      CREATE TABLE BANK
      (EMAIL VARCHAR(320) PRIMARY KEY     NOT NULL,
      NAME           TEXT    NOT NULL,
      PHONE INT ,
      BANKACCOUNT            INT     NOT NULL,
      ADDRESS        CHAR(200),
      PASSWORD         CHAR(20));
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>
